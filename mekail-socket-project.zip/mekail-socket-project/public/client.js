const socket = io();
let peerConnection;
let dataChannel;
let partnerId = null;

const config = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

const messages = document.getElementById('messages');
const input = document.getElementById('input');
const fileInput = document.getElementById('fileInput');

function addMessage(content, isImage = false) {
  const div = document.createElement('div');
  if (isImage) {
    const img = document.createElement('img');
    img.src = content;
    img.style.maxWidth = '200px';
    div.appendChild(img);
  } else {
    div.textContent = content;
  }
  messages.appendChild(div);
}

function sendMessage() {

  const text = input.value;

  console.log('text', text)
  if (text && dataChannel) {
    dataChannel.send(JSON.stringify({ type: 'text', content: text }));
    addMessage(`You: ${text}`);
    input.value = '';
  }
}

fileInput.addEventListener('change', () => {
  const file = fileInput.files[0];
  if (file && dataChannel) {
    const reader = new FileReader();
    reader.onload = () => {
      dataChannel.send(JSON.stringify({ type: 'image', content: reader.result }));
      addMessage(reader.result, true);
    };
    reader.readAsDataURL(file);
  }
});

socket.emit('join');

socket.on('ready', async (id) => {
  partnerId = id;
  createPeer(true);
});

socket.on('signal', async ({ from, signal }) => {
  partnerId = from;
  if (!peerConnection) createPeer(false);

  if (signal.type === 'offer') {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(signal));
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    socket.emit('signal', { to: partnerId, signal: answer });
  } else if (signal.type === 'answer') {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(signal));
  } else if (signal.candidate) {
    await peerConnection.addIceCandidate(new RTCIceCandidate(signal));
  }
});

function createPeer(isInitiator) {
  peerConnection = new RTCPeerConnection(config);

  if (isInitiator) {
    dataChannel = peerConnection.createDataChannel('chat');
    setupDataChannel();
    peerConnection.createOffer().then(offer => {
      peerConnection.setLocalDescription(offer);
      socket.emit('signal', { to: partnerId, signal: offer });
    });
  } else {
    peerConnection.ondatachannel = e => {
      dataChannel = e.channel;
      setupDataChannel();
    };
  }

  peerConnection.onicecandidate = e => {
    if (e.candidate) {
      socket.emit('signal', { to: partnerId, signal: e.candidate });
    }
  };
}

function setupDataChannel() {
  dataChannel.onmessage = e => {
    const msg = JSON.parse(e.data);
    if (msg.type === 'text') {
      addMessage(`Partner: ${msg.content}`);
    } else if (msg.type === 'image') {
      addMessage(msg.content, true);
    }
  };
}
