const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve static frontend
app.use(express.static(path.join(__dirname, 'public')));

// Optional: Any other API routes here
// app.use('/api', require('./apiRoutes'))

// Socket.io signaling
io.on('connection', socket => {
  console.log('User connected:', socket.id);

  socket.on('join', () => {
    const clients = Array.from(io.sockets.sockets.keys());
    if (clients.length > 1) {
      socket.emit('ready', clients.find(id => id !== socket.id));
    }
  });

  socket.on('signal', data => {
    io.to(data.to).emit('signal', {
      from: socket.id,
      signal: data.signal,
    });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

server.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
